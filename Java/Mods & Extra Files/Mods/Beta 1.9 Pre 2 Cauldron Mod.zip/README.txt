Cauldron mod for Beta 1.9 Prerelease 2
Edited by OgreSean

This mod edits 2 class files to add the cauldron block to minecraft.  This was a block used for creating potions that was not included in the 2nd prerelease, but was coded into the game and not assigned a block id.  This mod assigns the cauldron the block id 116.

Install Instructions:
To enable the mod, place all the files from the Enable folder into your minecraft.jar using 7zip or Winrar.
To disable the mod, place all the files from the Disable folder into your minecraft.jar using 7zip or Winrar.