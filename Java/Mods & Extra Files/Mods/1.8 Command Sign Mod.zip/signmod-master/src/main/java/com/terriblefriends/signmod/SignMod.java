package com.terriblefriends.signmod;

import net.fabricmc.api.ModInitializer;

public class SignMod implements ModInitializer {
	@Override
	public void onInitialize() {
		System.out.println("Hello Fabric world!");
	}
}
