package com.terriblefriends.bookmod.mixin.accessor;

import net.minecraft.nbt.NbtCompound;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;

@Mixin(NbtCompound.class)
public interface NbtCompoundAccessor {
    @Accessor("data")
    Map bookmod$getData();
}
