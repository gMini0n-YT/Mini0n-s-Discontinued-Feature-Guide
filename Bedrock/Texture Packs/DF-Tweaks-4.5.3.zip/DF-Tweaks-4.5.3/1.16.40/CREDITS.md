## Resources

- **Vanilla Tweaks** by the VanillaTweaks Team
  - Website: [vanillatweaks.net](https://vanillatweaks.net)

- **Bedrock Tweaks** by DrAv0011
  - Website: [bedrocktweaks.net](https://bedrocktweaks.net)


## Translators

- **Korean Translations** by Yeoseol and icecoffee1133


## Contributors

 - **Fish & Vindicator Textures** by [CalzLight](https://www.youtube.com/channel/UCj1eKVXc9USlbYSaGL82kDQ)

 - **Block Models** by [Kegan](https://github.com/KeganPlayz)